
# valid settings under OCP section in mycroft.conf
OCPRSSFeedExtractorConfig = {"rss": {}}
